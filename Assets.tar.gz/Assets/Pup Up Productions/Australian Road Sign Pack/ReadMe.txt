Thank you for downloading the Australian Sign Pack. 

This pack contains various assets based on Australian road signs, with 4k pbr textures.

The font used is "Transport" if you would like to create further materials or adjust the textures.

Please leave us a review if you enjoy this art pack!
If you have any questions or feedback, please contact me at pupupproductions@gmail.com

This pack was created in Western Australia.
We acknowledge the Whajuk people of the Noongar nation as the traditional custodians of the land and its waters. 
We pay our respect to Noongar elders past and present.