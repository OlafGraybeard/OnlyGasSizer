using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;
using UnityEngine;

public class Counters : MonoBehaviour
{
	
	private int cupsGold;
	private int cupsSilver;
	private int cupsBronze;
	
	public TextMeshProUGUI CounterGold;
	public TextMeshProUGUI CounterSilver;
	public TextMeshProUGUI CounterBronze;
	
	void Start()
	{
		CounterBronze.text = "0";
		CounterSilver.text = "0";
		CounterGold.text = "0";
	}
	
	public void Insert( string type )
	{
		switch ( type )
		{
			case "bronze":
			cupsBronze++;
			CounterBronze.text = "" + cupsBronze;
			break;
			case "silver":
			cupsSilver++;
			CounterSilver.text = "" + cupsSilver;
			break;
			case "gold":
			cupsGold++;
			CounterGold.text = "" + cupsGold;
			break;
		}
	}
	
}
