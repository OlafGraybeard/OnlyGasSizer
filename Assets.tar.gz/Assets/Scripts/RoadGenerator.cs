using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoadGenerator : MonoBehaviour
{
	// singletone //
	public static RoadGenerator instance;
	private void Awake() { instance = this; }
	
	// prefabs //
	public List<GameObject> PrefabList = new List<GameObject>();
	public List<GameObject> brriersList = new List<GameObject>();
	public List<GameObject> Cups = new List<GameObject>();
	
	// road properties //
	public int partCount = 7;
	public float speed = 1;
	public float maxSpeed = 10;
	public float curSpeed = 0;
	
	private List<GameObject> parts = new List<GameObject>();
	private int selector;
	private bool Moving;
	
	// barrier properties //
	private float b_pos = -2.5f;
	private float b_step = 1.25f;
	private float b_space = 20f;
	private float cup_space = 2f;
	
    // Start is called before the first frame update
    void Start()
    {
        ResetLvl();
		StartLvl();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Move();
    }
	
	private void CreatePart()
    {
		
        Vector3 pos = Vector3.zero;

        if (parts.Count > 0)
        {
            pos = parts[parts.Count - 1].transform.position + new Vector3(0, 0, 40);
        }
		selector = (selector + 1) % PrefabList.Count;
        GameObject go = Instantiate(PrefabList[selector], pos, Quaternion.identity);
        go.transform.SetParent(transform);
		createObjects(go);
        parts.Add(go);
    }
	
	private void createObjects( GameObject go )
	{
		if ( parts.Count > 0 )
		{
			Vector3 pos = Vector3.zero;
			Vector3 CurPos = go.transform.position;
			Vector3 Shift = new Vector3( 0, 0, -20 );
			float variator;
			float random;
			for ( int i = 0; i < 2; i++ )
			{
				variator = Random.Range(1,4);
				random = Random.Range(0f,1f);
				if ( random < 0.7 && random > 0.3 )
				{
					pos = CurPos + Shift + (new Vector3( 0, 0, b_space * i )) + (new Vector3( b_pos + ( b_step * variator ), 0, 0 ));
					
					GameObject bar = Instantiate(brriersList[1], pos, Quaternion.identity);
					bar.transform.SetParent(go.transform); 
					
				}
				if ( random > 0.7 )
				{
					for( int j = 0; j < 3; j++ )
					{
						pos = CurPos + Shift + (new Vector3( 0, 0, b_space * i + cup_space * j )) + (new Vector3( b_pos + ( b_step * variator ), 0, 0 ));
						
						GameObject cup = Instantiate(Cups[j], pos, Quaternion.identity);
						cup.transform.SetParent(go.transform);
					}
				}
			}
		}
	}
	
	private void Move()
	{
		if (speed < 1) { return; }
		
		foreach ( GameObject part in parts )
		{
			part.transform.position -= new Vector3(0, 0, speed * Time.deltaTime);
		}
		
		if (parts[0].transform.position.z < -25)
        {
            Destroy(parts[0]);
            parts.RemoveAt(0);
            CreatePart();
        }
	}
	
	public void StartLvl()
	{
		speed = curSpeed;
	}
	public void PauseLvl()
	{
		curSpeed = speed;
		speed = 0;
	}
	
	public void ResetLvl()
	{
		speed = 0;
		while (parts.Count > 0)
        {
            Destroy(parts[0]);
            parts.RemoveAt(0);
        }
		for( int i = 0; i < partCount; i++ )
		{
			CreatePart();
		}
	}
	
}
