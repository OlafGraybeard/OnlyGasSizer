using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PlayerController : MonoBehaviour
{
	
	private Rigidbody rigBody;
	
	
	private float limit = 2.5f;
	private float maxSpeed;
	
	public Counters counters;
	
    private bool TouchBegan() { return Input.GetMouseButtonDown(0); }
    private bool TouchEnded() { return Input.GetMouseButtonUp(0); }
    private bool Touch() { return Input.GetMouseButton(0); }
	
	private Vector2 firstPosition;
	private Vector2 deltaPos;
	
	private Quaternion YawRotate;
	
	public Animator DeathScreen;
	public bool controll = true;
	public Vector2 TouchPos() { return (Vector2)Input.mousePosition; }
	
	
    void Start()
    {
        maxSpeed = RoadGenerator.instance.maxSpeed;
    }
	
    void FixedUpdate()
    {
        Moving();
    }
	
	
	void Moving()
	{
		if ( controll == true )
		{
			float X = deltaPos.x;
			if (EventSystem.current.IsPointerOverGameObject()) return;
			if ( Touch() && RoadGenerator.instance.speed < maxSpeed )
			{
				RoadGenerator.instance.speed += 3 * Time.deltaTime;
			}
			if ( !Touch() && RoadGenerator.instance.speed > 0 )
			{
				RoadGenerator.instance.speed -= 10 * Time.deltaTime;
			}
			if ( RoadGenerator.instance.speed < 0 )
			{
				RoadGenerator.instance.speed = 0;
			}
			
			if ( TouchBegan() )
			{
				firstPosition = TouchPos();
			}
			if ( Touch() )
			{
				deltaPos = firstPosition - TouchPos();
				if ( transform.position.x <= limit && transform.position.x >= -limit )
				{
					transform.position += new Vector3( ( -deltaPos.x / 200 ) * ( RoadGenerator.instance.speed / maxSpeed ), 0, 0 );
				}
			}
			else
			{
				deltaPos = new Vector2(0,0);
			}
			if ( transform.position.x >= limit )
			{
				transform.position += new Vector3( -0.01f, 0, 0 );
				transform.position += new Vector3( -0.01f, 0, 0 );
			}
			if (transform.position.x <= -limit)
			{
				transform.position += new Vector3( 0.01f, 0, 0 );
			}
		}
	}
	
	void OnTriggerEnter(Collider toutch)
    {
        switch ( toutch.gameObject.tag )
		{
			case "barrier":
				RoadGenerator.instance.speed = 0;
				controll = false;
				Debug.Log("barrier");
				DeathScreen.SetTrigger("Fade");
			break;
			case "obstacle":
				RoadGenerator.instance.speed -= 20 * Time.deltaTime;
				Debug.Log("obstacle");
			break;
			case "bronze":
				Debug.Log("bronze");
				Destroy(toutch.gameObject);
				counters.Insert("bronze");
			break;
			case "silver":
				Debug.Log("silver");
				Destroy(toutch.gameObject);
				counters.Insert("silver");
			break;
			case "gold":
				Debug.Log("gold");
				Destroy(toutch.gameObject);
				counters.Insert("gold");
			break;
			default :
			break;
		}
    }
	
	public void Reset()
	{
		transform.position = Vector3.zero;
		transform.rotation = new Quaternion( 0, 0, 0, 0 );
		controll = true;
	}
}
